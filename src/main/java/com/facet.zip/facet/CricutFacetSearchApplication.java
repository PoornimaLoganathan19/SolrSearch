package com.facet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CricutFacetSearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(CricutFacetSearchApplication.class, args);
	}
}
