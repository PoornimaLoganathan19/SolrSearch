package com.facet;

import java.util.List;

import org.springframework.data.solr.repository.Query;
import org.springframework.data.solr.repository.SolrCrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends SolrCrudRepository<Product, String>{
	
	@Query("productId:*?0* OR displayName:*?0*")
	List<Product> findByProductId(String productId);

}
