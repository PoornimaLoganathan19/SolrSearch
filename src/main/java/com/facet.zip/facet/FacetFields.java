package com.facet;

import java.util.List;

public class FacetFields {

	private String facetId;
	private String displayName;
	private String type;
	private int sequenceId;
	private List<Options> options;
	
	public String getFacetId() {
		return facetId;
	}
	public void setFacetId(String facetId) {
		this.facetId = facetId;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getSequenceId() {
		return sequenceId;
	}
	public void setSequenceId(int sequenceId) {
		this.sequenceId = sequenceId;
	}
	public List<Options> getOptions() {
		return options;
	}
	public void setOptions(List<Options> options) {
		this.options = options;
	}
	public FacetFields(String facetId, String displayName, String type, int sequenceId, List<Options> options) {
		super();
		this.facetId = facetId;
		this.displayName = displayName;
		this.type = type;
		this.sequenceId = sequenceId;
		this.options = options;
	}
	public FacetFields() {
		super();
		// TODO Auto-generated constructor stub
	}
}
