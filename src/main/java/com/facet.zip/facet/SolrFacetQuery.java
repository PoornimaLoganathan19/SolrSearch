package com.facet;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.request.QueryRequest;
import org.apache.solr.client.solrj.response.FacetField;
import org.apache.solr.client.solrj.response.FacetField.Count;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import static com.facet.constants.FacetFields.*;
import static com.facet.constants.OptionTypes.*;
/**
 * 
 * @author PL00557272
 * 
 */
@RestController
@RequestMapping("/cricut")
public class SolrFacetQuery {
	
//	@Autowired
//	private ProductRepository productRepository;
	
	@RequestMapping("/facetQuery")
	public String getFacetQuery() throws SolrServerException {
		
		HttpSolrServer solr = new HttpSolrServer(SOLR_URL);
	
		SolrQuery query = new SolrQuery().setFacet(true);
		// set facet field and facet query for solr
		query.setQuery("color:raspberry AND priceValue:[* TO 300]");
		query.setRows(15);
		query.addFacetField("color");
		query.addFacetQuery("priceValue:[* TO 500]");
		
		// Query Request for solr
		QueryRequest request = new QueryRequest(query);
		
		// Query Response for solr
		QueryResponse response = request.process(solr);
		
		// Overall query results containing the records related query and facet properties
       //System.out.println("RESPONSE" +response.getResults());
		
		SolrDocumentList docs = response.getResults();
		long numFound = docs.getNumFound();
		System.out.println("NumberFOund: " +numFound);
		int docsCounter = 0;
		for(SolrDocument doc: docs) {
			docsCounter++;
			System.out.println("doccounter" +docsCounter);
			for(Entry<String, Object> fields : doc.entrySet()) {
				String name = fields.getKey();
				Object value = fields.getValue();
				System.out.println("\t" + name + "=" + value  );
			}
		}
		// To query out the facet output
		System.out.println("Response: " +response.getFacetFields());
		
		List<FacetField> facetFields = response.getFacetFields();
		for(int i = 0; i< facetFields.size(); i++) {
			FacetField facetField = facetFields.get(i);
			System.out.println("facetFields: " +facetField);
			List<Count> facetInfo = facetField.getValues();
			System.out.println("facetInfo: " +facetInfo);
			for(FacetField.Count facetInstance : facetInfo) {
				System.out.println(facetInstance.getName() + ":" + 
			facetInstance.getCount());
			}
		}	
		// Output for facet query
		System.out.println("FacetQuery: " +response.getFacetQuery());
		// Overall Query
		System.out.println("SOLR QUERY:");
		System.out.println(SOLR_URL + "/select?indent=on&" + query + "&wt=json" );
		
	return "success";
	}
	
	@RequestMapping("/getAllDocs")
	public Map<String, List<Map<String, Object>>> getAllIndexedDocuments() throws SolrServerException {
		
		List<Map<String, Object>> documents = new ArrayList<>();
		Map<String,List<Map<String, Object>>> product = new HashMap<>();
		
		HttpSolrServer solr = new HttpSolrServer(SOLR_URL);
		
		SolrQuery query = new SolrQuery();
		
		query.setQuery(DEFAULT_QUERY);
		query.setRows(ROWS);
		QueryRequest request = new QueryRequest(query);
		QueryResponse response = request.process(solr);
		
		for(SolrDocument solrDocument : response.getResults()) {
			documents.add(solrDocument);
		}
		product.put("products", documents);
	    return product;
	}
	
	@RequestMapping("/getOneDoc/{productId}")
	public Map<String, List<Map<String, Object>>> getOneIndexedDocuments(@PathVariable String productId) throws SolrServerException {
		
		List<Map<String, Object>> documents = new ArrayList<>();
		Map<String,List<Map<String, Object>>> product = new HashMap<>();
		
		HttpSolrServer solr = new HttpSolrServer(SOLR_URL);
		
		SolrQuery query = new SolrQuery();
		
		query.setQuery(productId);
		query.setRows(ROWS);
		QueryRequest request = new QueryRequest(query);
		QueryResponse response = request.process(solr);
		
		for(SolrDocument solrDocument : response.getResults()) {
			documents.add(solrDocument);
		}
		product.put("products", documents);
	    return product;
	}

	@RequestMapping("/getFacetFields")
	public Map<String, List<FacetFields>> getAllFacets() throws SolrServerException {
       
		HttpSolrServer solr = new HttpSolrServer(SOLR_URL);
		
		SolrQuery query = new SolrQuery().setFacet(true);
		
		query.setQuery(DEFAULT_QUERY);
		query.setRows(FACET_ROWS);
		query.addFacetField("color");
//		query.addFacetField("categoryId");
		QueryRequest request = new QueryRequest(query);
		QueryResponse response = request.process(solr);
		
		Map<String, List<FacetFields>> facet = new HashMap<>();
		
		List<FacetFields> facetList = new ArrayList<>();
		final List<Options> options = new ArrayList<Options>();
		
		List<FacetField> facetFields = response.getFacetFields();
		for(int i=0; i < facetFields.size(); i++) {
			
			System.out.println("Facet Size" +facetFields.size());
			
			FacetField facetField = facetFields.get(i);
			System.out.println(facetField.getName());
			
			int counter = 1;
			int count = 1;

			List<Count> facetInfos = facetField.getValues();
			for(FacetField.Count facetInstance : facetInfos) {
				
				String name = facetInstance.getName();
				long count1 = facetInstance.getCount();
				
				System.out.println("Name:" + name + "/t Count:" +count1);
				options.add(new Options(facetInstance.getName(),facetInstance.getCount(),counter));
				counter++;
			}
			facetList.add(new FacetFields(facetField.getName(), facetField.getName(), null, count, options));
			count++;	
		}
		facet.put("facets", facetList);
		return facet;
	}	
}
