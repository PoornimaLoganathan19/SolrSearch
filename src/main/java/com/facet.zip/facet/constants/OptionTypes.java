package com.facet.constants;

public final class OptionTypes {

	public static final String RADIO = "radio";
	public static final String CHECK_BOX = "checkbox";
}
